# MindSphere SDK for Node.js 

## Introduction

The MindSphere SDK for Node.js provides service specific SDKs which have an integral dependency on the Core Module. MindSphere SDK Node.js Core provides many core features like authorization, token handling, exception handling, api invoker, logging features etc.

The pre-requisites required for using the SDK is explained [here](https://developer.mindsphere.io/resources/mindsphere-sdk-node/nodereadme.html#prerequisites-to-use-the-mindsphere-sdk-for-nodejs)

## Installation Instructions

The installation instructions are explained [here](https://developer.mindsphere.io/resources/mindsphere-sdk-node/nodereadme.html#installation-instructions)

## Features

Mindsphere SDK Node.js Core provides following features:

##### Authorization handling
The MindSphere SDK Node.js Core provides an easy authorization handling mechanism. Developers can configure user authorization tokens or service credentials. The MindSphere SDK Node.js Core provides multiple ways for setting up service credentials for use in an API client. Environment variables can be set for service credential configuration to generate authorization for API calls.

##### Token handling and validation
The Mindsphere SDK Node.js Core provides the ability to generate a token, regenerate the token on expiry. Also validates the user token against its expiry time, issuer, token type and token algorithm .

See [Token handling](https://developer.mindsphere.io/resources/mindsphere-sdk-node/token_handling.html) for more information.

##### API Client and credentials configuration
The Mindsphere SDK Node.js Core provides a common interface for clients and rest client configuration options to pass connection settings like proxy , host environment , connection time out and socket timeout.

See [API Client and Credentials Configuration](https://developer.mindsphere.io/resources/mindsphere-sdk-node/nodereadme.html#service-client-and-credentials-configuration) for more information.


##### Logging

Logging in MindSphere SDK for Node.js is provided using the `debug` module.

See [Logging](https://developer.mindsphere.io/resources/mindsphere-sdk-node/logging.html) for more information.

## Code Samples

The code samples for all the Service clients can be found at [Code Samples](https://developer.mindsphere.io/resources/mindsphere-sdk-node/apidocs/MindSphere_AssetManagement.html)

## Js doc

The complete js documentation for all the classes of the MindSphere SDK for Node.js can be found [here](https://developer.mindsphere.io/resources/mindsphere-sdk-node/jsdoc/index.html)